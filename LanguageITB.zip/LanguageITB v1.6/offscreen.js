chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'read-clipboard') {
      // Creem un element invisible per enganxar-hi el text
      const input = document.createElement('textarea');
      document.body.appendChild(input);
      input.focus();
      
      // Executem l'ordre d'enganxar
      document.execCommand('paste');
      
      const value = input.value;
      document.body.removeChild(input);
      
      // Enviem el text de tornada al background.js
      sendResponse(value);
    }
    return true; // Manté el canal obert per a la resposta asíncrona
  });
async function setupOffscreen() {
  const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (contexts.length > 0) return;
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['CLIPBOARD'],
    justification: 'Llegir text per LanguageTool'
  });
}

async function executarCorreccio(textExtern = null) {
  try {
    let textAFuncionar = textExtern;

    if (!textAFuncionar) {
      await setupOffscreen();
      textAFuncionar = await chrome.runtime.sendMessage({ type: 'read-clipboard' });
    }

    if (!textAFuncionar || textAFuncionar.trim().length === 0) {
      console.log("No hi ha text per corregir.");
      return;
    }

    // --- MILLORA: Cercar si ja existeix la pestanya ---
    const tabs = await chrome.tabs.query({ url: "https://languagetool.org/*" });
    let tab;

    if (tabs.length > 0) {
      // Si ja existeix, l'activem i la seleccionem
      tab = tabs[0];
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
    } else {
      // Si no existeix, la creem
      tab = await chrome.tabs.create({ url: "https://languagetool.org/ca/" });
    }
    // ------------------------------------------------

    // Injectem el text (mantenim el teu timeout de 2 segons com demanaves)
    setTimeout(() => {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (t) => {
          const intentarInjectar = () => {
            const editor = document.querySelector('.lt-textarea__textarea.welcome-editor__textarea');
            if (editor) {
              editor.focus();
              editor.innerText = t;
              editor.dispatchEvent(new Event('input', { bubbles: true }));
            } else {
              setTimeout(intentarInjectar, 500);
            }
          };
          intentarInjectar();
        },
        args: [textAFuncionar]
      });
    }, 2000);

  } catch (err) {
    console.error("Error:", err);
  }
}

// Clic a la icona
chrome.action.onClicked.addListener(() => executarCorreccio());

// Menú contextual
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "enviarLT_Seleccio",
    title: "Corregir selecció amb LT",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "enviarLT_Seleccio") {
    executarCorreccio(info.selectionText);
  }
});